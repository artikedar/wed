package org.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.service.FilmServiceImpl;
import com.flp.service.IFilmService;

/**
 * Servlet implementation class FilmSearch
 */
public class FilmSearch extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IFilmService filmService=new FilmServiceImpl();
		List<Film> films=new ArrayList<>(); //comparison objects
		films=filmService.getAllFilms(); //comparison objects
		//System.out.println("Got Film:"+films);
		
		Actor actor=new Actor();
		Film film=new Film(); //object to be searched
		int i=0;
		List<Film> serFilm=new ArrayList<>(); //search results
		
		
		//Getting Film Id		
		String fimId=request.getParameter("filmId");
		int serFilmId=Integer.parseInt(fimId);
		System.out.println("FilmId of the film to be searched is:"+serFilmId);
		if(serFilmId!=0)
		{  
			film.setFilm_ID(serFilmId);
			i=film.getFilm_ID();
			serFilm= filmService.searchFilm(film);
		}
	
		//Getting Film Title
		String title=request.getParameter("filmTitle");
		System.out.println("Title of the film to be searched is:"+title);
		if(title!=null&&title.length()!=0)
		{
			film.setTitle(title);
			serFilm= filmService.searchFilm(film);
		}
		
		//Getting Actors
		String[] actorNew=request.getParameterValues("actor"); //actors to be searched
		System.out.println("Actors of the film to be searched are:"+actorNew);
		
		if(!(request.getParameter("actor").equals("-select-")))
		{
		if(Integer.parseInt(request.getParameter("actor"))>0)
		{
		Set<Actor> actorList=new HashSet<>();
		for(String actor2:actorNew)
		{
			Actor actor3=new Actor();
			int actNew=Integer.parseInt(actor2);
			actor3.setActor_Id(actNew);		
			actorList.add(actor3);
		}
		film.setActors(actorList);
		serFilm= filmService.searchFilm(film);
		}
		}
		
		//Getting Languages
		String[] otherLanguages=request.getParameterValues("orgLang");
		System.out.println("Original language of the film to be searched is:"+otherLanguages);
		if(request.getParameter("orgLang")!="-select-")
		{
		if(Integer.parseInt(request.getParameter("orgLang"))>0)
		{
		List<Language> langList=new ArrayList<>();
		for(String langs:otherLanguages){
			Language langOther=new Language();
			langOther.setLanguage_Id(Integer.parseInt(langs));
			langList.add(langOther);
				                                                                                       
		}
		film.setLanguages(langList);
		serFilm= filmService.searchFilm(film);
		
		}
		}
		
		
		System.out.println("Binding "+i+"to id of the film to be searched");
		System.out.println("This is the film to be searched:"+film);
		if(request.getParameter("actor")!="-select-"&&request.getParameter("orgLang")!="-select-")
		{
		serFilm= filmService.searchFilm(film);
		}
		System.out.println("the result:"+serFilm);
		
		
		
		
		
	
		
		//Print the Found Film
		PrintWriter out=response.getWriter();
		out.println("<html>"
				+ "<h4>Got following Results</h4>"
				+ "<head>Search Results</head>"
				+ "<body>"
				+ "<table border='1'>"
				
				+ "<tr>"
				+ "<th>FilmId</th>"
				+ "<th>Title</th>"
				+ "<th>Description</th>"
				+ "<th>Release Year</th>"
				+ "<th>Original Language</th>"
				+ "<th>Rental Duration</th>"
				+ "<th>Length</th>"
				+ "<th>Replacement Cost</th>"
				+ "<th>Rating</th>"
				+ "<th>Special Features</th>"
				+ "<th>Category</th>"
				+ "<th>List of Actors</th>"
				+ "<th>List of Other Languages</th>"
				+ "</tr>");
				
		if(!serFilm.isEmpty()){		
		for(Film allFilms:serFilm){
			
			out.println(
					
			"<tr>"
			+"<td>"+allFilms.getFilm_ID()+"</td>"
			+"<td>"+allFilms.getTitle()+"</td>"
			+"<td>"+allFilms.getDescription()+"</td>"
			+"<td>"+allFilms.getReleaseYear()+"</td>"
			
			
			+"<td>"+(allFilms.getOriginalLanguage()).getName()+"</td>"
			
			
			
			+"<td>"+allFilms.getRentalDuration()+"</td>"
			+"<td>"+allFilms.getLength()+"</td>"
			+"<td>"+allFilms.getReplacementCost()+"</td>"
			+"<td>"+allFilms.getRatings()+"</td>"
			+"<td>"+allFilms.getSpecialFeatures()+"</td>"
			+"<td>"+(allFilms.getCategory()).getName()+"</td>");
			
			Set<Actor> act=allFilms.getActors();
			out.println("<td>");
			for(Actor actors:act){
				String actor2=actors.getFirst_Name()+actors.getLast_Name();
				out.println(actor2); 
			}
			out.println("</td>");
			
			List<Language> langs=allFilms.getLanguages();
			out.println("<td>");
			for(Language otherLan:langs){
				String lang=otherLan.getName();
				out.println(lang); 
			}
			out.println("</td>");
			
			out.println(
			
			 "</tr>");
		}
		}
		out.println(		
		"</table>"
		+ "</body>"
		+ "</html>");

		
	}

}
