package org.capgemini.pojo;

import java.util.Date;

public class Account {

	private double accNo;
	private String accName;
	private Date openDate;
	private String accType;
	private int balAmount;
	private Date dob;
	private String gender;
	
	//No Argument Constructor
	public Account(){}
	
	//Argument Constructor
	public Account(double accNo, String accName, Date openDate, String accType, int balAmount, Date dob,
			String gender) {
		super();
		this.accNo = accNo;
		this.accName = accName;
		this.openDate = openDate;
		this.accType = accType;
		this.balAmount = balAmount;
		this.dob = dob;
		this.gender = gender;
	}
	

	//Getters and Setters
	public double getAccNo() {
		return accNo;
	}

	public void setAccNo(double accNo) {
		this.accNo = accNo;
	}

	public String getAccName() {
		return accName;
	}

	public void setAccName(String accName) {
		this.accName = accName;
	}

	public Date getOpenDate() {
		return openDate;
	}

	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public int getBalAmount() {
		return balAmount;
	}

	public void setBalAmount(int balAmount) {
		this.balAmount = balAmount;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}


	//toString method
	@Override
	public String toString() {
		return "Account [accNo=" + accNo + ", accName=" + accName + ", openDate=" + openDate + ", accType=" + accType
				+ ", balAmount=" + balAmount + ", dob=" + dob + ", gender=" + gender + "]";
	}

	
	
}
