package org.capgemini.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AccountForm {

	@RequestMapping("/hello")
	public ModelAndView sayHello(){
		
		return new ModelAndView("helloPage","msg","Hello World!");
	}
	
	@RequestMapping("/accForm")
	public String showAccForm(Map<String, Object> maps){
		
		List<String> accTypes=new ArrayList<String>();
		accTypes.add("Savings");
		accTypes.add("Current");
		accTypes.add("Loan");
		accTypes.add("RD");
		accTypes.add("FD");
		
		maps.put("accForm", new AccountForm());
		maps.put("accTypes", accTypes);
		
		return "accForm";
	}
	
}
